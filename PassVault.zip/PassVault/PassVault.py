import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
from cryptography.fernet import Fernet
import pyperclip

# Filenames
KEY_FILENAME = "vault_key.key"
VAULT_FILENAME = "vault.json"

# Generate/load encryption key
if not os.path.exists(KEY_FILENAME):
    key = Fernet.generate_key()
    with open(KEY_FILENAME, "wb") as f:
        f.write(key)
else:
    with open(KEY_FILENAME, "rb") as f:
        key = f.read()
fernet = Fernet(key)

# Companies list (deduplicated, alphabetized)
COMPANIES = sorted(list(set([
    "3M", "Activision Blizzard", "Adobe", "Adidas", "Airbnb", "Alphabet",
    "Amazon", "AMC Entertainment", "AMD", "American Express", "Apple",
    "ASML Holding", "AT&T", "AutoZone", "BAE Systems", "Bank of America",
    "Barclays", "Berkshire Hathaway", "Best Buy", "BlackRock", "BMW",
    "Booking.com", "BP (British Petroleum)", "Broadcom", "Canon",
    "Capital One", "Caterpillar", "Chevron", "Cisco Systems", "Citigroup",
    "Coca-Cola", "Costco Wholesale", "CVS Health", "Danaher",
    "Deere & Company", "Disney+", "Dropbox", "Duolingo", "eBay",
    "Electronic Arts (EA Games)", "ExxonMobil", "Facebook (Meta Platforms)",
    "Ford Motor", "General Motors", "Goldman Sachs", "Google",
    "Hartford Financial Group", "Hasbro", "Home Depot", "Honda Motor",
    "HP Inc.", "HSBC", "Huawei", "IBM", "Intel", "Johnson & Johnson",
    "JPMorgan Chase", "Kellogg", "KFC", "Kia Motors", "Kohl’s", "LinkedIn",
    "Lloyds Banking Group", "L’Oréal", "Lyft", "Mastercard", "McDonald’s",
    "Medtronic", "Meta Platforms", "Microsoft", "Morgan Stanley", "Netflix",
    "Nike", "Nordstrom", "Notion", "Nutanix", "Nvidia", "Oracle", "PepsiCo",
    "Pfizer", "Pinterest", "PlayStation", "ProtonMail", "ProtonVPN",
    "Qualcomm", "Quora", "Robinhood", "Roku", "Salesforce", "Samsung",
    "Shopify", "Siemens", "Snapchat", "Sony", "Spotify", "Starbucks",
    "Stripe", "Target", "Tesla", "TikTok", "T-Mobile US", "Toyota Motor",
    "Twitch", "Twitter", "Uber", "Unilever", "UnitedHealth Group",
    "US Bank", "Visa", "Vodafone", "Walmart", "Wells Fargo", "WhatsApp",
    "WordPress", "X (formerly Twitter)", "Yahoo", "YouTube", "Zoom", "Zscaler"
])))

# Vault functions
def load_vault():
    if not os.path.exists(VAULT_FILENAME):
        return {"entries": {}}
    with open(VAULT_FILENAME, "rb") as f:
        encrypted_data = f.read()
    try:
        decrypted = fernet.decrypt(encrypted_data)
        return json.loads(decrypted.decode("utf-8"))
    except:
        return {"entries": {}}

def save_vault(vault):
    encrypted = fernet.encrypt(json.dumps(vault).encode("utf-8"))
    with open(VAULT_FILENAME, "wb") as f:
        f.write(encrypted)

# Main app
class PassVaultApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PassVault")
        self.entries = []
        self.show_passwords = False
        self.vault = load_vault()

        # Menu bar
        menu_bar = tk.Menu(self.root)
        self.root.config(menu=menu_bar)
        help_menu = tk.Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="About", command=self.show_about)
        menu_bar.add_cascade(label="Help", menu=help_menu)

        # Scrollable frame
        container = ttk.Frame(root)
        canvas = tk.Canvas(container, height=400)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.scroll_frame = ttk.Frame(canvas)
        self.scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        container.grid(row=0, column=0, sticky="nsew")
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Control buttons
        control_frame = ttk.Frame(root)
        add_button = ttk.Button(control_frame, text="+ Add Entry", command=self.add_entry)
        toggle_button = ttk.Button(control_frame, text="Show/Hide Passwords", command=self.toggle_passwords)
        save_button = ttk.Button(control_frame, text="Save Vault", command=self.save_all)

        add_button.pack(side="left", padx=5, pady=5)
        toggle_button.pack(side="left", padx=5, pady=5)
        save_button.pack(side="left", padx=5, pady=5)
        control_frame.grid(row=1, column=0, sticky="ew")

        # Configure resizing
        root.grid_rowconfigure(0, weight=1)
        root.grid_rowconfigure(1, weight=0)
        root.grid_columnconfigure(0, weight=1)

        # Load existing entries
        for company, info in self.vault["entries"].items():
            self.add_entry(company, info["password"])

    # Entry management
    def add_entry(self, company_name=None, password_text=None):
        row = ttk.Frame(self.scroll_frame)
        company_var = tk.StringVar(value=company_name if company_name else COMPANIES[0])
        company_menu = ttk.Combobox(row, textvariable=company_var, values=COMPANIES, state="readonly")
        password_var = tk.StringVar(value=password_text if password_text else "")
        password_entry = ttk.Entry(row, textvariable=password_var, show="*")
        copy_button = ttk.Button(row, text="Copy", command=lambda p=password_var: pyperclip.copy(p.get()))
        delete_button = ttk.Button(row, text="Delete", command=lambda r=row: self.delete_entry(r))

        company_menu.pack(side="left", padx=5, pady=5)
        password_entry.pack(side="left", padx=5, pady=5)
        copy_button.pack(side="left", padx=5, pady=5)
        delete_button.pack(side="left", padx=5, pady=5)
        row.pack(fill="x", padx=5, pady=2)
        self.entries.append((row, company_var, password_var))

    def delete_entry(self, row):
        for i, (r, _, _) in enumerate(self.entries):
            if r == row:
                r.destroy()
                self.entries.pop(i)
                break

    def toggle_passwords(self):
        self.show_passwords = not self.show_passwords
        for row, _, password_var in self.entries:
            entry_widget = row.winfo_children()[1]
            entry_widget.config(show="" if self.show_passwords else "*")

    def save_all(self):
        vault_dict = {"entries": {}}
        for _, company_var, password_var in self.entries:
            if password_var.get().strip():
                vault_dict["entries"][company_var.get()] = {"password": password_var.get()}
        save_vault(vault_dict)
        messagebox.showinfo("PassVault", "Vault saved successfully!")

    # About menu
    def show_about(self):
        messagebox.showinfo(
            "About PassVault",
            "PassVault v1.0\nCreated by Björn Vidar Odinson\nA simple, secure local password manager."
        )

# Main
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("850x500")
    root.minsize(850, 500)
    app = PassVaultApp(root)
    root.mainloop()
